package com.example.cuadraticaprueba2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Scanner entrada = new Scanner(System.in);

         double a, b, c, delta, sol1, sol2;

         System.out.println("Programa formula cuadratica");

         System.out.println("Ingrese el valor A:");
         a = entrada.nextDouble();

         if (a ==0){
             System.out.println("cero no es un valor posible par A.");
         }
         else {

             System.out.println("Ingrese el valor B:");
             b = entrada.nextDouble();

             System.out.println("Ingrese el valor C:");
             c = entrada.nextDouble();

             delta = (b*b) - (4*a*c);
             System.out.println("Delta: "+delta);
             if (delta < 0) {
                 System.out.println("Su ecuacion no tiene solucion");
             }

             else if (delta == 0) {
                 sol1 = -b/(2*a);
                 System.out.println("Su ecuacion tiene solucion");
                 System.out.println("Solucion: "+sol1);

             }

             else
             {
                 sol1 = (-b + Math.sqrt(delta))/(2*a);
                 sol2 = (-b - Math.sqrt(delta))/(2*a);
                 System.out.println("Su ecuacion tiene 2  soluciones ene los reales");
                 System.out.println("Solucion: "+sol1);
                 System.out.println("Solucion: "+sol2);
             }

         }



    }
}