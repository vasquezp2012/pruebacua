package com.example.cuadraticaprueba2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Calcular extends AppCompatActivity {
    TextView a,b,c;
    Button calcularcua;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcular);

        a = findViewById(R.id.a);
        b = findViewById(R.id.b);
        c = findViewById(R.id.c);
        calcularcua = findViewById(R.id.calcularcua);

        String a = getIntent().getExtras().getString("a");
        String b = getIntent().getExtras().getString("b");
        String c = getIntent().getExtras().getString("c");






    }
}